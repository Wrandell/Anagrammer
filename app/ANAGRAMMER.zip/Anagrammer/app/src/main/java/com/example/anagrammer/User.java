package com.example.anagrammer;

public class User {
    String fName;
    String email;
    String existence;
    String pword;

    public User(){

    }

    public User(String fName, String email, String existence, String pword) {
        this.fName = fName;
        this.email = email;
        this.existence = existence;
        this.pword = pword;
    }

    public String getfName() {
        return fName;
    }

    public String getEmail() {
        return email;
    }

    public String getExistence() {
        return existence;
    }

    public String getPword() {
        return pword;
    }
}
