package com.example.anagrammer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.auth.User;

public class register extends AppCompatActivity implements View.OnClickListener {
    TextView backBtn;
    EditText fullName, userName, passWord, age;
    ProgressBar progressBar;
    Button registerBtn;
    private FirebaseAuth userDb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        backBtn = (TextView) findViewById(R.id.backBtn);
        fullName = (EditText) findViewById(R.id.fullName);
        userName = (EditText) findViewById(R.id.userName);
        passWord = (EditText) findViewById(R.id.passWord);
       age= (EditText) findViewById(R.id.age);
       registerBtn = (Button) findViewById(R.id.registerBtn);
       userDb = FirebaseAuth.getInstance();

       backBtn.setOnClickListener(this);
       registerBtn.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.backBtn:
                startActivity(new Intent(getApplicationContext(),login.class));
                break;
            case R.id.registerBtn:
                registerEntity();
                break;
        }

    }

    private void registerEntity(){
        String fName = fullName.getText().toString().trim();
        String email = userName.getText().toString().trim();
        String existence = age.getText().toString().trim();
        String pword = passWord.getText().toString().trim();
        
        if(fName.isEmpty()){
            fullName.setError("Full Name is Required!*");
            fullName.requestFocus();
            return;
        }

        if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
           userName.setError("Please Enter Valid Email Address");
            userName.requestFocus();
            return;
        }

        if(existence.isEmpty()){
            age.setError("Age is Required!*");
            age.requestFocus();
            return;
        }

        if(pword.isEmpty()){
           passWord.setError("Password is Required!*");
            passWord.requestFocus();
            return;
        }

        if(pword.length() < 6) {
            passWord.setError("Minimum of 6 Characters");
            passWord.requestFocus();
            return;
        }

        progressBar.setVisibility(View.VISIBLE);
        userDb.createUserWithEmailAndPassword(email, pword)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()){
                            FirebaseDatabase.getInstance().getReference("Users")
                                    .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                    .setValue(user).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if(task.isSuccessful()){
                                        Toast.makeText(register.this, "Successfully Registered", Toast.LENGTH_SHORT).show();
                                        progressBar.setVisibility(View.GONE);
                                    }else{
                                        Toast.makeText(register.this, "Failed", Toast.LENGTH_SHORT).show();
                                        progressBar.setVisibility(View.GONE);
                                    }
                                }
                            });

                        } else{
                            Toast.makeText(register.this, "Failed", Toast.LENGTH_SHORT).show();
                            progressBar.setVisibility(View.GONE);
                        }
                    }
                });
    }

}