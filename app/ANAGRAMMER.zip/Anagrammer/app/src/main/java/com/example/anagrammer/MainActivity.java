package com.example.anagrammer;

import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private TextView wordTv, scoreG, countdown;
    private EditText wordEnteredTv;
    private Button validate, newGame;
    private String wordToFind;
    int score1 = 0;
    int timer = 30000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        wordTv = (TextView) findViewById(R.id.wordTv);
        wordEnteredTv = (EditText) findViewById(R.id.wordEnteredEt);
        validate = (Button) findViewById(R.id.validate);
        validate.setOnClickListener(this);
        newGame = (Button) findViewById(R.id.newGame);
        newGame.setOnClickListener(this);
        scoreG = (TextView)findViewById(R.id.score);
        countdown = (TextView)findViewById(R.id.timer);

        newGame();

        scoreG.setText("" + score1);

        new CountDownTimer(timer, 1000) {
            @Override
            public void onTick(long l) {
                countdown.setText("" + l/1000);
            }

            @Override
            public void onFinish() {
                Intent intent = new Intent(getApplicationContext(), score.class);
                startActivity(intent);

            }
        }.start();
    }
    @Override
    public void onClick(View view) {
        if (view == validate) {
            validate();
        } else if (view == newGame) {
            newGame();
        }
    }

    private void validate() {
        String w = wordEnteredTv.getText().toString();
        if (wordToFind.equals(w)) {
            score1++;
            scoreG.setText("" + score1);
            Toast.makeText(this, "Congratulations ! You found the word " + wordToFind, Toast.LENGTH_SHORT).show();
            newGame();
        } else {
            Toast.makeText(this, "Retry !", Toast.LENGTH_SHORT).show();
        }
    }

    private void newGame() {
        wordToFind = Anagram.randomWord();
        String wordShuffled = Anagram.shuffleWord(wordToFind);
        wordTv.setText(wordShuffled);
        wordEnteredTv.setText("");
    }
}

